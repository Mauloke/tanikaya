<?php
/*
Template Name: Landing Page
*/
?>
<?php get_header(); ?>
<div id="break"></div>



<?php get_footer(); ?>