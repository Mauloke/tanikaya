	<div id="footer" class="row">
    	<div class="footer-top col-md-12 hidden-xs">
        	<div class="row">
    			<div id="logo_small" class="col-md-11 col-md-offset-1"></div>
        	</div>
            <div class="row">
            	<div id="fcon1" class="col-md-2 col-md-offset-1">
                	<p><b>PT. Tanikaya Multi Sarana</b></p>
                    <p>
                    Jl. Poltangan Raya No.50 C
                    Tanjung Barat - Jagakarsa
                    Jakarta Selatan -12530
                    Indonesia
                    </p>
                </div>
                <div id="fcon2" class="col-md-2">
                    <p>Phone
                    +62 21 788 30995
                    </p>
                    <p>
                    Fax
                    +62 21 788 30994</p>
                </div>
                <div id="fcon3" class="col-md-2">
                </div>
                <div id="fcon4" class="col-md-2 col-md-offset-2">
                </div>
            </div>
        </div>
        <div class="footer-bottom col-md-12">
        	<div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                	<div id="copyright">
                    	<p>TANIKAYA &copy; 2015. All rights reserved.</p>
                    </div>
                </div>
                <div class="col-md-3 col-md-offset-6 col-sm-6 col-xs-12 hidden-xs">
                	<div id="social">
                        <div id="conwus">CONNECT WITH  US</div>
                        <div id="facebook"><i class="fa fa-facebook fa-fw"></i></div>
                        <div id="twitter"><i class="fa fa-twitter fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
</body>
</html>